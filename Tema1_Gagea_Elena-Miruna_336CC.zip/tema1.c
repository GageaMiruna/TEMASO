#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "compare.h"
#define COMAND_SIZE 20000
struct Element {
	char *data;
	int prio;
	struct Element *next;
};

void freeList(struct Element *head)
{
	struct Element *tmp;

	while (head != NULL) {
		tmp = head;
		head = head->next;
		free(tmp->data);
		free(tmp);
	}

}

struct Element *newElement(char *d, int p, int *eroare)
{
	struct Element *temp;

	temp = (struct Element *)malloc(sizeof(struct Element));
	//trimit cod de eroare
	if (temp == NULL) {
		(*eroare) = 12;
		return 0;
	}
	temp->data = (char *)malloc((strlen(d) + 1) * sizeof(char));
	//trimit cod de eroare
	if (temp->data == NULL) {
		(*eroare) = 12;
		return 0;
	}

	strcpy(temp->data, d);
	temp->prio = p;
	temp->next = NULL;
	return temp;
}

char *top(struct Element **head)
{
	return (*head)->data;
}

void pop(struct Element **head)
{
	struct Element *temp = *head;
	(*head) = (*head)->next;
	free(temp->data);
	free(temp);
}

int isEmpty(struct Element *head)
{
	if (head == NULL)
		return 0;
	return 1;
}

int insert(struct Element **head, char *d, int p)
{
	struct Element *start = (*head);
	struct Element *temp;
	int eroare = 0;

	temp = newElement(d, p, &eroare);
	//trimit cod de eroare
	if (eroare == 12)
		return 12;

	if (*head == NULL) {
		*head = temp;
		return 0;
	}
	//verific daca elem curent are prioritata mai mica decat head
	if (compare((*head)->prio, p) < 0) {

		temp->next = *head;
		(*head) = temp;

	} else {
		//caut elementul dupa care sa inserez
		while (start->next != NULL && compare(start->next->prio, p) > 0)
			start = start->next;

		temp->next = start->next;
		start->next = temp;
	}
	return 0;
}

int parse_line(struct Element **pq, FILE *fi)
{

	int prio;
	char *nume;
	char comand[COMAND_SIZE];
	char cuvant[COMAND_SIZE];
	char *aux;
	int eroare = 0;

	if (fi != NULL) {

		while (fgets(comand, COMAND_SIZE, fi) != NULL) {
			if (comand[strlen(comand)-1] == '\n')
				comand[strlen(comand)-1] = '\0';
			//verific daca am rand gol
			if (strlen(comand) == 0)
				continue;
			strcpy(cuvant, strtok(comand, " "));
			if (strcmp(cuvant, "insert") == 0) {
				nume = strtok(NULL, " ");
				aux = strtok(NULL, " ");
			//verific daca dupa insert vin nume si prioritate
				if (nume != NULL && aux != NULL) {
					if (strtok(NULL, " "))
						continue;

					prio = atoi(aux);
					eroare = insert(pq, nume, prio);
					//trimit cod de eroare
					if (eroare == 12)
						return 12;
				}
			}
			if (strcmp(cuvant, "top") == 0) {
				//verific corectitudinea comenzii
				if (strtok(NULL, " "))
					continue;
				//verific daca stiva e goala
				if ((*pq) != NULL) {
					printf("%s\n", top(pq));
					fflush(stdout);
				}
			}

			if (strcmp(cuvant, "pop") == 0) {
				//verific corectitudinea comenzii
				if (strtok(NULL, " "))
					continue;
				//verific daca stiva e goala
				if ((*pq) != NULL)
					pop(pq);
			}
		}
	}
	return 0;
}

int main(int argc, char *argv[])
{

	FILE *fi;
	struct Element *pq = NULL;
	int eroare;
	int file_it;

	if (argc >= 2) {

		for (file_it = 1; file_it < argc; file_it++) {

			fi = fopen(argv[file_it], "r");
			if (fi != NULL) {
				eroare = parse_line(&pq, fi);
				if (eroare == 12)
					exit(12);
				fclose(fi);
			} else
				continue;
		}

	} else
		parse_line(&pq, stdin);

	freeList(pq);
	return 0;
}
